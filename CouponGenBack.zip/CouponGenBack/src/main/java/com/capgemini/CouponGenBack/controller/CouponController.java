package com.capgemini.CouponGenBack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.CouponGenBack.model.Coupons;
import com.capgemini.CouponGenBack.service.CouponService;

@RestController
@RequestMapping("/api/v1")
public class CouponController {
	
	@Autowired
	private CouponService couponservice;
	
	@GetMapping("/coupons")
	public ResponseEntity<List<Coupons>> getAllCoupons(){
		List<Coupons> coupons= couponservice.getAll();
		if(coupons.isEmpty()||coupons==null)
			return new ResponseEntity("Sorry! Coupon details not available!",HttpStatus.NOT_FOUND);
	
		return new ResponseEntity<List<Coupons>>(coupons,HttpStatus.OK);
	}
	
	@PostMapping("/coupons1")
	public void create(@RequestBody Coupons coupons){
		couponservice.save(coupons);
		
		//return new ResponseEntity<Coupons>(coupons,HttpStatus.OK);
	}
	
	
}
