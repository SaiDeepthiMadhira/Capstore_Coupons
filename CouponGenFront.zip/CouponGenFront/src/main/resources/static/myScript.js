
function validateCouponForm(){
	var coupcode=couponsform.couponCode.value;
	var description=couponsform.couponDescription.value;
	var amount=couponsform.couponAmount.value;
	var issuedate=couponsform.issueDate.value;
	var expirydate=couponsform.expiryDate.value;
	
	var dateformat = /^\d{4}/\d{2}/\d{2}$/
	
	var flag=false;
	/*if(id==""||id==null){
		alert("Please enter id");
	}*/
	
	else if(coupcode=="" || coupcode==null)
		{
		alert("Please enter couponcode");
		}
	
	else if(description=="" || description==null)
	{
	alert("Please enter description");
	}
	else if(amount=="" || amount==null)
	{
	alert("Please enter amount");
	}
	else if(issuedate=="" || issuedate==null)
	{
	alert("Please enter expiry date");
	}
	else if(dateformat.test(issuedate) == false)
	{
alert("Please enter a vaild date mm/dd/yyyy");
	}
	
	
	else if(expirydate=="" || expirydate==null)
	{
	alert("Please enter expiry date");
	}
	else if(dateformat.test(expirydate) == false)
	{
alert("Please enter a vaild date mm/dd/yyyy");
	}
	
	else{
		flag=true;
		alert("Coupon Created successfully");
	}
		return flag;
}
