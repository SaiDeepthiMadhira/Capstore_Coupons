package com.capgemini.CouponGenFront.controller;


import javax.validation.Valid;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.CouponGenFront.model.Coupons;

@Controller
public class MyController {
	@RequestMapping("/")
	public String deepthi(ModelMap map) {
		//System.out.println("hello");
		map.put("coupons", new Coupons());
		return "GenerateCoupon";
	}
	
	@RequestMapping("/GenerateCoupon")
	public String getPilotForm(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
		final String uri="http://localhost:8090/CouponGenBack/api/v1/coupons";
		RestTemplate restTemplate=new RestTemplate();
		
		Coupons[] coupons= restTemplate.getForObject(uri, Coupons[].class);
		
		
		map.put("coupons",coupons);
		map.put("coupons", new Coupons());
		
		//return "GenerateCoupon";
		return "redirect:GenerateCoupon";
	}
	
	@RequestMapping("/savecoupon")
	public String showCouponDetails(
			 @ModelAttribute("coupons") Coupons coupons,ModelMap map) {
		
		 System.out.println(coupons);	
		 
		
			final String uri="http://localhost:8090/CouponGenBack/api/v1/coupons1";
			RestTemplate restTemplate=new RestTemplate();
			
		
			restTemplate.postForEntity(uri,coupons,Coupons.class);
			//restTemplate.put(uri,coupons,Coupons.class);
		
		
		map.put("coupons",new Coupons());

		return "GenerateCoupon";
	}
	
}
